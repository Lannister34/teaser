window.data_config = function(form, config){

    this.form = document
            .querySelector(form);

    this.tools = {

        "init"        :   {},
        "config"      :   {},
        "form"        :   this.form,

        "loop"        :   function(data){
            var a = function(callback){
                var step = 0;
                for(step; step < data.length; step++){
                    callback(data[step], step, data);
                };
            };

            var o = function(callback){
                var prop;
                for(prop in data){
                    data.hasOwnProperty(prop) &&
                        callback(data[prop], prop, data);
                };
            };

            return {
                "run" : Array.isArray(data)
                            ? a : o
            };
        },

        "nodes"       :   function(node, selector){
            var result = [];

            this.loop(node.querySelectorAll(selector || "*"))
                .run(function(n){
                    n instanceof Node &&
                        result.push(n);
                });

            return result;
        },

        "data-set"    :   {
            "other" : function(e){
                e.onchange = function(){
                    this.maker.options
                        .change(this.maker.options["change-data"](this));
                };
            },

            "text" : function(e){
                e.onkeyup = function(){
                    this.maker.options
                        .change(this.maker.options["change-data"](this));
                };
            },

            "interval" : function(e){
                e.onkeyup = function(){
                    this[this.maker.value].search(/^\d+$/) > -1 &&
                        this.maker.options
                            .re_init(this.maker.options.form.maker.output());
                };
            },

            "range" : function(e){
                e.oninput = function(){
                    this.maker.options
                        .change(this.maker.options["change-data"](this));
                };

                e.onchange = function(){
                    this.maker.options
                        .change(this.maker.options["change-data"](this));
                };
            },

            "js-color" : function(e){

                new jscolor(e, {
                    onFineChange : function(){
                        var _this = this.targetElement;
                        _this.maker.options
                            .change(_this.maker.options["change-data"](_this))
                    }
                });
                
            },

            "drop-zone" : function(e){
                new Dropzone(e, config.options.gallery)

                .on("addedfile", function(e){
                    this.on("thumbnail", function(e){
                        var _this = this.element;
                        _this.maker.parent.maker.options
                        .re_init(_this.maker.parent.maker.options.form.maker.output());
                    });
                })

                .on("removedfile", function(){
                    var _this = this.element;
                    _this.maker.parent.maker.options
                        .re_init(_this.maker.parent.maker.options.form.maker.output());
                });
            },
        },

        "change-data" : function(e){
            return {
                "name" : e.maker.parent.maker.name,
                "data" : e.maker.parent.maker.output()
            };
        }
    };

    var init = this.tools.init;

    init.list = function(list){

        list.maker.set = function(){
            var _this = this;
            this.count = -1;

            this.list = [];

            this.options.loop(this.options.nodes(this.self, "[data-item]"))
                .run(function(item, i, list){
                    _this.count++;
                    item.maker.name = _this.name + "#" + _this.count;
                    _this.list.push(item);
                });
        };

        list.maker.item = function(item, options){
            var _this = this;

            item.maker = {
                "options" :   options,
                "parent"  :   this.self,
                "self"    :   item,
                "type"    :   item.getAttribute("data-type"),
            };

            var add_button = item
                .querySelector("[data-list-add]");

            add_button && (function(){

                add_button.maker = {
                    "parent" : item
                };

                add_button.onclick = function(){
                    return false;
                };

                add_button.onmousedown = function(){
                    this.maker.parent.maker
                        .parent.maker.add(this.maker.parent);
                };

            })();

            var remove_button = item
                .querySelector("[data-list-remove]");

            remove_button && (function(){

                remove_button.maker = {
                    "parent" : item
                };

                remove_button.onclick = function(){
                    return false;
                };

                remove_button.onmousedown = function(){
                    this.maker.parent.maker
                        .parent.maker.remove(this.maker.parent);
                };

            })();

            this.options.init[item.maker.type](item);
        };

        list.maker.output = function(){
            var result = [];
            this.options.loop(this.list)
                .run(function(item, i){
                    result[i] = item.maker.output();
                });
            return result;
        };

        list.maker.add = function(item){
            var temp = this.temp.cloneNode(true);
            this.self.insertBefore(temp, item.nextSibling);
            this.item(temp, this.options);
            this.set();
            this.options.re_init(this.options.form.maker.output());
        };

        list.maker.remove = function(item){
            var _this = this;
            this.list.length < 2 ?
                alert("Список не может быть пустым")
                    : (function(){
                        _this.self.removeChild(item);
                        _this.set();
                        _this.options.re_init(_this.options.form.maker.output());
                    })();
        };

        list.maker.options.loop(list.maker.options.nodes(list))
            .run(function(item){

                item.hasAttribute("data-item") &&
                    (function(){
                        list.maker.temp = item.cloneNode(true);
                        list.maker.item(item, list.maker.options);
                    })();

            });

        list.maker.set();

    };

    init.gallery = function(item, options){

        item.maker.gallery = item
            .querySelector("[data-set=drop-zone]");

        item.maker.gallery.maker = {
            "options" :   options,
            "self"    :   item.maker.gallery,
            "parent"  :   item
        };

        item.maker.options["data-set"]
            ["drop-zone"](item.maker.gallery);

        item.maker.output = function(){
            //console.log(this.gallery.dropzone)
            var result = [];
            this.gallery.dropzone.files < 1 ?
                result.push(this.gallery.dropzone["def-image"])
                    : this.options.loop(this.gallery.dropzone.files)
                            .run(function(img){
                                result.push(img.dataURL);
                            });
            return result;
        };
    };

    init.value = function(item, options){

        var child = item.
            querySelector("[data-set]");

        child.maker = {
            "options" :   options,
            "self"    :   child,
            "parent"  :   item,
            "value"   :   child.hasAttribute("data-value") ?
                            child.getAttribute("data-value")
                                : "value"
        };

        child.getAttribute("data-set") ?
            child.maker.options["data-set"][child.getAttribute("data-set")](child)
                : child.maker.options["data-set"]["other"](child);

        item.maker
            .child = child;

        item.maker.output = function(){
            return this.child[this.child.maker.value];
        };
    };

    init.option = function(item, parent){

        item.maker = {
            "options"      :   parent.maker.options,
            "name"         :   item.getAttribute("data-name"),

            "value"        :   item.hasAttribute("data-value") ?
                                    option.getAttribute("data-value")
                                        : "value",
            "self"         :   item,
            "parent"       :   parent
        };

        item.hasAttribute("data-set") ?
            item.maker.options["data-set"][item.getAttribute("data-set")](item)
                : item.maker.options["data-set"]["other"](item);
    };

    init.options = function(item){

        item.maker.issues = [];
        
        item.maker.output = function(){
            var result = {};
            this.options.loop(this.issues)
                .run(function(option){

                    result[option.maker.name] =
                        option[option.maker.value];
                });

            return result;
        };

        item.maker.options.loop(item.maker.options.nodes(item, "[data-name]"))
            .run(function(option){

                item.maker
                    .issues.push(option);

                item.maker.options
                    .init.option(option, item);
            });

    }

    init.row = function(row, options){

        row.maker = {
            "options" :   options,
            "self"    :   row,
            "name"    :   row.getAttribute("data-row"),
            "type"    :   row.getAttribute("data-type"),
        };

        row.maker.options.config[row.maker.name] = row;
        row.maker.options.init[row.maker.type](row, options);
    };

    this.form.maker = {
        "options" :   this.tools,
        "self"    :   this.form,

        "output"  :   function(){
            var result = {};
            this.options.loop(this.options.config)
                .run(function(row){
                    result[row.maker.name] = row.maker.output();
                });
            return result;
        },

        "start"   :   function(){
            var _this = this;
            this.options.loop(this.options.nodes(this.self, "[data-row]"))
                .run(function(row){
                     _this.options.init.row(row, _this.options);
                });
        }
    };

    config.maker = {};

    config.maker.form = this.form;

    config.maker.output = function(){
        return this.form.maker.output(); 
    };

    config.maker.change = function(callback){
        this.form.maker.options.change = callback; 
    };

    config.maker.init = function(callback){
        this.form.maker.options.re_init = callback; 
    };

    this.form.maker.start();

};