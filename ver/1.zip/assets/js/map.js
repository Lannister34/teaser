window.driver = {

    "mobile" : {

        "sticker" : {

            "bevel" : "bevel"
        }
    },

    "desktop" : {

    }
}