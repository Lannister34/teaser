var test = function(node){
	console.log(node);
}

window.set_map = function(map){
    var section = document.createElement("section");
    section.setAttribute("data-select", "platform");

    var box = document.createElement("div");
    box.classList.add("box");
    var box_in = document.createElement("div");

    box.appendChild(box_in);
    section.appendChild(box)

    Object.keys(map).forEach(function(name) {
        var item = document.createElement("span");
        item.innerHTML = name.toUpperCase();
        item.setAttribute("data-platform", name);
        item.setAttribute("onclick", "test(this)");
        box_in.appendChild(item);
    });

    document.body.appendChild(section)
};