window.promo_composer = function(){

    /* -------------------- OPTIONS -------------------- */

    var set_options = (function(){

        var set_loop = function(data){
            var a = function(callback){
                var step = 0;
                for(step; step < data.length; step++){
                    callback(data[step], step, data);
                };
            };

            var o = function(callback){
                var prop;
                for(prop in data){
                    data.hasOwnProperty(prop) && callback(data[prop], prop, data);
                };
            };

            return {
                "run" : Array.isArray(data) ? a : o
            };
        };

        var set_data = (function(){

            var data_asign = function(init, target){
                set_loop(init).run(function(property, key){
                    target[key] = property;
                });
                return target;
            };

            return {
                "assign" : data_asign
            };

        })();

        var set_css = (function(){

            var prx = {
                "properties" : /text-size-adjust|user-select|transform|transition|box-shadow|animation|filter/i,
                "prefix" : ["", "webkit", "moz", "ms", "o", "ie", "wap", "khtml"]
            };

            var set_fix = function(element, param, obj){
                set_loop(prx.prefix).run(function(item, i){
                    var p = i ? "-" + item + "-" : "";
                    element.style[p + param] = obj[param];
                });
            };

            var set_style = function(element, obj){
                set_loop(obj).run(function(param, key){
                    key.match(prx.properties) ? 
                        set_fix(element, key, obj) : element.style[key] = param;
                });
            };

            var get_properties = function(obj){
                var result = "";
                set_loop(obj).run(function(property, key){
                    key.match(prx.properties) ? set_loop(prx.prefix).run(function(prefix, i){
                        var new_prefix = i ? "-" + prefix + "-" : "";
                        result += new_prefix + key + ":" + property + ";";
                    }) : result += key + ":" + property + ";"
                });
                return result;
            };

            var set_rule = function(parent, obj){

                var init = "sheet" in parent ? 
                   "insertRule" in parent["sheet"] ? 
                        ["sheet", "insertRule"] : "addRule" in parent["sheet"] ? 
                            ["sheet", "addRule"] : null : null;

                var inject_style = function(parent, selector, rules, index){
                    var index = index || null;
                    !init ? 
                        parent.innerHTML += selector + "{" + rules + "}" : init[1] === "addRule" ? 
                            parent[init[0]][init[1]](selector, rules, index) :
                                parent[init[0]][init[1]](selector + "{" + rules + "}", index);

                    init && parent.sheet.init_count++;
                };

                init ? 
                    parent.sheet.init_count ?
                        false : parent.sheet.init_count = 0 : false;

                set_loop(obj).run(function(selector, key){
                    inject_style(parent, key, get_properties(selector), parent.sheet.init_count);
                });
            };

            var set_animation = function(parent, obj){
                set_loop(obj).run(function(animation, name){
                    var sign =  "/" + "* " + name + " *" + "/\n\n";
                    var animation_box = (function(){
                        var result = "";
                        set_loop(prx.prefix).run(function(fix, i){
                            var prefix = i ? "-" + fix + "-" : "";
                            result += "@" + prefix + "keyframes " + name + " {\n" + (function(){
                                var step = "";
                                set_loop(animation).run(function(anim, s){
                                    step += s + "{" + get_properties(anim) + "}\n";
                                });
                                return step;
                            })() + "}\n\n";
                        });
                        return result;
                    })();
                    parent.innerHTML += sign + animation_box;
                });
            };

            var set_media = function(parent, obj){
                set_loop(obj).run(function(statement, name){
                    var state_case = "@media " + name + " {\n" + (function(){
                        var result = "";
                        set_loop(statement).run(function(selector, key){
                            result += key + "{" + get_properties(selector) + "}";
                        });
                        return result;
                    })() + "\n}\n";
                    parent.innerHTML += state_case; 
                });
            };

            return {
                "fix"          :      set_fix,
                "style"        :      set_style,
                "rule"         :      set_rule,
                "animation"    :      set_animation,
                "media"        :      set_media,
                "properties"   :      get_properties
            }

        })();

        return {
            "loop" : set_loop,
            "data" : set_data,
            "css" : set_css,
        }

    })();

    /* --------------------- PAGE --------------------- */

    var set_page = (function(){

        var pull_data_fallback = {
            "promosize" : .25
        };

        var pull_data = function (name) {
            var r = new RegExp('[\\?&]' + name.replace(/[\[]/, '\\[')
                        .replace(/[\]]/, '\\]') + '=([^&#]*)')
                            .exec(location.search);

            return !r ? pull_data_fallback[name] : 
                    decodeURIComponent(r[1].replace(/\+/g, ' '))
                        .replace(/-/g, '/');
        };

        /* ----------- */

        var size_type = .25;

        var get_agent = (function(){
            var an = window.navigator.userAgent.toLowerCase();

            var am = function(naming){
                return an.match(naming);
            };

            return {
                "android"  :  am(/android/i),
                "ios"      :  am(/iphone|ipad|ipod/i),
                "uc"       :  am(/ucbrowser/i)
            }
        })();

        var get_size = function(){
            var box = document.querySelector(form_config.preview);

            return {

                in_width   :   parseInt(window.getComputedStyle(box).width),
                in_height   :   parseInt(window.getComputedStyle(box).height),

                av_width    :  parseInt(window.getComputedStyle(box).width),
                av_height   :  parseInt(window.getComputedStyle(box).height) / .25
            }
        };

        var get_scale = function(){
            var size = get_size(),
                scale = size.in_width < size.in_height / size_type && size.av_width < size.av_height ||
                        size.in_width > size.in_height / size_type && size.av_width > size.av_height ? 
                            size.in_width / size.av_width 
                                : size.in_width / size.av_height;

            return scale > 1 ? scale : 1;
        };

        var get_device = function(){
            var size = get_size(),
                scale = get_scale(),
                width = size.in_width,
                height = size.av_height,
                mobile = width < height && width < 450 * scale && height < 850 * scale ||
                         width > height && width < 850 * scale && height < 450 * scale;

            return {

                "orientation" : {
                    "landscape"  :   width > height,
                    "portrait"   :   width < height
                },

                "type" : {
                    "mobile" : mobile,
                    "tablet" : mobile ? false : true
                }
            };
        };

        return {
            "agent" : get_agent,
            "size" : get_size,
            "scale" : get_scale,
            "device" : get_device,
            "type" : size_type,
            "pull" : pull_data
        };

    })();

    /* -------------------- EVENTS -------------------- */

    var set_events = (function(){

        var evt_list = {};

        var run_evt = function(type, evt){
            var evt = evt || null;
            type in evt_list ? set_options.loop(evt_list[type]).run(function(func){
                func(evt);
            }) : console.warn('there is no ' + type + " event in window"); 
        };

        var set_evt = function(holder){
            holder["resize"] = function(){
                set_options.loop(evt_list).run(function(e, type){
                    run_evt(type, event);
                });
            };
        };

        var add_evt = function(type){
            type in evt_list || (evt_list[type] = {});
        };

        var add_func = function(type, name, func){
            type in evt_list ?
                name in evt_list[type] ?
                    console.warn(type + " event already has " + name + " function")
                        : evt_list[type][name] = func
                            : (function(){
                                add_evt(type);
                                evt_list[type][name] = func;
                            })();
        };

        var remove_evt = function(type){
            type in evt_list && (delete evt_list[type]);
        };

        var remove_func = function(type, name){
            type in evt_list ?
                func in evt_list[type] && (delete evt_list[type][name])
                    : false;
        };

        return {
            "list"            :     evt_list,
            "set"             :     set_evt,
            "run"             :     run_evt,

            "add"    : {
                "evt"         :     add_evt,
                "func"        :     add_func
            },

            "remove" : {
                "evt"         :     remove_evt,
                "func"        :     remove_func
            }
        };

    })();

    return {
        "options"   :   set_options,
        "page"      :   set_page,
        "events"    :   set_events
    };

};